TP sur le Falcon de Fran�ois Lepan et Alexis Linke.

Pour ce TP nous avons impl�ment� une fonction permettant de cr�er du magn�tisme vers une boule (Vec3D) pass�e en param�tre. 
La prochaine �tape �tait d'ajouter plusieurs boules, cependant nous n'avons pas eu le temps de le tester.

Pour les n boules il suffit de rappeler la fonction avec un autre Vec3D.
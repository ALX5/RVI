Linke Alexis

TP réalisé jusqu'au texturage du triangle.

J'ai rencontré quelques problèmes à bien définir les vertices de la sphère et je n'ai donc pas pu faire la suite.

Linke Alexis

TP réalisé jusqu'au texturage du triangle.

J'ai rencontré quelques problèmes à bien définir les vertices de la sphère et je n'ai donc pas pu faire la suite.

La vidéo était trop grosse pour que je puisse l'uploader sur moodle, il faut donc la rajouter au dossier.
